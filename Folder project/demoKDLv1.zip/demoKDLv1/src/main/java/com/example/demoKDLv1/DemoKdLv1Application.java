package com.example.demoKDLv1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoKdLv1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoKdLv1Application.class, args);
	}

}
